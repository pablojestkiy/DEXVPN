from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "DEXVPN API"
    environment: str = "development"
    database_url: str = "sqlite:///./dexvpn.db"
    jwt_secret: str = "CHANGE_ME"
    access_token_minutes: int = 60
    admin_api_key: str = "CHANGE_ME"
    panel_type: str = "3x-ui"
    panel_base_url: str = ""
    panel_api_token: str = ""
    panel_inbound_ids: str = ""
    panel_flow: str = ""
    panel_total_gb: float = 0
    panel_limit_ip: int = 0
    panel_limit_hwid: int = 1
    panel_verify_tls: bool = True
    public_base_url: str = "http://127.0.0.1:8000"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def inbound_ids(self) -> list[int]:
        values = [part.strip() for part in self.panel_inbound_ids.split(",") if part.strip()]
        return [int(value) for value in values]

settings = Settings()
