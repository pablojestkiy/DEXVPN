from abc import ABC, abstractmethod
from dataclasses import dataclass

@dataclass
class ProvisionedClient:
    client_id: str
    vless_uri: str

class PanelAdapter(ABC):
    @abstractmethod
    async def provision_client(self, user_id: str, expires_at) -> ProvisionedClient:
        raise NotImplementedError

    @abstractmethod
    async def revoke_client(self, client_id: str) -> None:
        raise NotImplementedError
