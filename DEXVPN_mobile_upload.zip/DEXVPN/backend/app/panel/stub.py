from .base import PanelAdapter, ProvisionedClient

class StubPanelAdapter(PanelAdapter):
    async def provision_client(self, user_id: str, expires_at) -> ProvisionedClient:
        raise RuntimeError("Panel adapter is not configured for your exact control panel.")

    async def revoke_client(self, client_id: str) -> None:
        raise RuntimeError("Panel adapter is not configured.")
