from __future__ import annotations

from datetime import datetime, timezone
from urllib.parse import quote
import httpx

from .base import PanelAdapter, ProvisionedClient
from ..config import settings


class ThreeXUIError(RuntimeError):
    pass


class ThreeXUIAdapter(PanelAdapter):
    """Adapter for current MHSanaei/3x-ui REST API (Bearer API token)."""

    def __init__(self):
        if not settings.panel_base_url or not settings.panel_api_token:
            raise ThreeXUIError("Set PANEL_BASE_URL and PANEL_API_TOKEN in backend/.env")
        if not settings.inbound_ids:
            raise ThreeXUIError("Set PANEL_INBOUND_IDS to one or more existing VLESS inbound IDs")
        self.base_url = settings.panel_base_url.rstrip("/")
        self.headers = {
            "Authorization": f"Bearer {settings.panel_api_token}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }
        self.timeout = httpx.Timeout(20.0, connect=10.0)
        self.verify_tls = settings.panel_verify_tls

    async def _request(self, method: str, path: str, *, json_body=None, allow_not_found=False):
        url = f"{self.base_url}{path}"
        async with httpx.AsyncClient(
            headers=self.headers,
            timeout=self.timeout,
            verify=self.verify_tls,
            follow_redirects=False,
        ) as client:
            response = await client.request(method, url, json=json_body)
        if response.status_code == 404:
            return None
        if response.is_error:
            raise ThreeXUIError(f"3x-ui HTTP {response.status_code}: {response.text[:300]}")
        try:
            payload = response.json()
        except ValueError as exc:
            raise ThreeXUIError("3x-ui returned a non-JSON response") from exc
        if isinstance(payload, dict) and payload.get("success") is False:
            message = str(payload.get("msg", "unknown error"))
            if allow_not_found and ("not found" in message.lower() or "record" in message.lower()):
                return payload
            raise ThreeXUIError(f"3x-ui rejected request: {message}")
        return payload

    @staticmethod
    def _obj(payload):
        if payload is None:
            return None
        return payload.get("obj") if isinstance(payload, dict) and "obj" in payload else payload

    async def get_client(self, email: str):
        payload = await self._request(
            "GET",
            f"/panel/api/clients/get/{quote(email, safe='')}",
            allow_not_found=True,
        )
        return self._obj(payload)

    async def _get_links(self, email: str) -> list[str]:
        payload = await self._request("GET", f"/panel/api/clients/links/{quote(email, safe='')}")
        obj = self._obj(payload)
        if not isinstance(obj, list):
            raise ThreeXUIError("3x-ui did not return a client links array")
        links = [item for item in obj if isinstance(item, str) and item.startswith("vless://")]
        if not links:
            raise ThreeXUIError(
                "No VLESS share link returned. Check that selected inbound IDs are enabled VLESS inbounds."
            )
        return links

    async def provision_client(self, user_id: str, expires_at: datetime) -> ProvisionedClient:
        if expires_at.tzinfo is None:
            expires_at = expires_at.replace(tzinfo=timezone.utc)
        email = f"dexvpn-{user_id}@clients.dexvpn.invalid"
        expiry_ms = int(expires_at.timestamp() * 1000)

        existing = await self.get_client(email)
        client_data = {
            "email": email,
            "enable": True,
            "expiryTime": expiry_ms,
            "totalGB": settings.panel_total_gb,
            "limitIp": settings.panel_limit_ip,
            "limitHwid": settings.panel_limit_hwid,
            "comment": f"DEXVPN account {user_id}",
        }
        if settings.panel_flow:
            client_data["flow"] = settings.panel_flow

        if existing:
            await self._request(
                "POST",
                f"/panel/api/clients/update/{quote(email, safe='')}",
                json_body=client_data,
            )
        else:
            await self._request(
                "POST",
                "/panel/api/clients/add",
                json_body={"client": client_data, "inboundIds": settings.inbound_ids},
            )

        links = await self._get_links(email)
        return ProvisionedClient(client_id=email, vless_uri="\n".join(links))

    async def revoke_client(self, client_id: str) -> None:
        email = client_id
        existing = await self.get_client(email)
        if not existing:
            return
        await self._request(
            "POST",
            f"/panel/api/clients/update/{quote(email, safe='')}",
            json_body={"email": email, "enable": False},
        )

    async def get_client_links(self, email: str) -> list[str]:
        return await self._get_links(email)
