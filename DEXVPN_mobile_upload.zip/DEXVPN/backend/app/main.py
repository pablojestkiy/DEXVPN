from datetime import datetime, timedelta, timezone
from uuid import uuid4
from fastapi import FastAPI, Depends, HTTPException, Header
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from jose import JWTError
from .db import Base, engine, get_db
from .models import User, Plan, Subscription, FreeUsageWindow, VpnUsageSession
from .schemas import RegisterIn, LoginIn, TokenOut, PlanOut, ProfileOut, PurchaseVerifyIn, AdminProvisionIn
from .security import hash_password, verify_password, create_token, decode_token
from .config import settings
from .panel.stub import StubPanelAdapter
from .panel.three_x_ui import ThreeXUIAdapter, ThreeXUIError

Base.metadata.create_all(bind=engine)
app = FastAPI(title="DEXVPN API", version="0.3.0")
FREE_LIMIT_SECONDS = 3 * 60 * 60
FREE_WINDOW = timedelta(hours=24)
HEARTBEAT_MAX_SECONDS = 30
oauth2 = OAuth2PasswordBearer(tokenUrl="/auth/login")

def get_panel():
    if settings.panel_type.lower() == "3x-ui":
        return ThreeXUIAdapter()
    return StubPanelAdapter()

DEFAULT_PLANS = [
    ("month", "1 месяц", 30, 29900),
    ("quarter", "3 месяца", 90, 79900),
    ("halfyear", "6 месяцев", 180, 139900),
    ("year", "12 месяцев", 365, 249900),
]

@app.on_event("startup")
def seed_plans():
    db = next(get_db())
    try:
        for code, title, days, price in DEFAULT_PLANS:
            if not db.query(Plan).filter_by(code=code).first():
                db.add(Plan(code=code, title=title, duration_days=days, price_minor=price))
        db.commit()
    finally:
        db.close()

def current_user(token: str = Depends(oauth2), db: Session = Depends(get_db)) -> User:
    try:
        subject = decode_token(token).get("sub")
        user = db.query(User).filter_by(email=subject).first()
    except JWTError:
        user = None
    if not user:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    return user

def is_expired(expires_at):
    if expires_at is None:
        return True
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)
    return expires_at <= datetime.now(timezone.utc)


def as_utc(value: datetime) -> datetime:
    return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value.astimezone(timezone.utc)

def premium_active(db: Session, user_id: int) -> bool:
    sub = db.query(Subscription).filter_by(user_id=user_id).first()
    return bool(sub and sub.status == "active" and not is_expired(sub.expires_at))

def get_or_reset_usage_window(db: Session, user_id: int, start_if_missing: bool = False) -> FreeUsageWindow | None:
    now = datetime.now(timezone.utc)
    usage = db.query(FreeUsageWindow).filter_by(user_id=user_id).first()
    if usage is None and start_if_missing:
        usage = FreeUsageWindow(user_id=user_id, window_started_at=now, used_seconds=0)
        db.add(usage)
        db.flush()
    elif usage is not None and usage.window_started_at is None and start_if_missing:
        usage.window_started_at = now
    elif usage is not None and usage.window_started_at is not None and now >= as_utc(usage.window_started_at) + FREE_WINDOW:
        usage.window_started_at = now
        usage.used_seconds = 0
        # A session must never carry over into a fresh 24-hour allowance.
        db.query(VpnUsageSession).filter_by(user_id=user_id, active=True).update({"active": False})
        db.flush()
    return usage

def usage_payload(db: Session, user: User, usage: FreeUsageWindow | None) -> dict:
    premium = premium_active(db, user.id)
    used = usage.used_seconds if usage else 0
    remaining = max(0, FREE_LIMIT_SECONDS - used)
    return {
        "is_premium": premium,
        "ads_enabled": not premium,
        "limit_seconds": None if premium else FREE_LIMIT_SECONDS,
        "used_seconds": used,
        "remaining_seconds": None if premium else remaining,
        "window_resets_at": None if premium or not usage or not usage.window_started_at else as_utc(usage.window_started_at) + FREE_WINDOW,
    }

@app.get("/usage/status")
def usage_status(user: User = Depends(current_user), db: Session = Depends(get_db)):
    usage = get_or_reset_usage_window(db, user.id)
    db.commit()
    active_session = db.query(VpnUsageSession).filter_by(user_id=user.id, active=True).first()
    return {**usage_payload(db, user, usage), "session_active": bool(active_session)}

@app.post("/usage/start")
def usage_start(user: User = Depends(current_user), db: Session = Depends(get_db)):
    usage = get_or_reset_usage_window(db, user.id, start_if_missing=True)
    if premium_active(db, user.id):
        db.commit()
        return {"allowed": True, "unlimited": True, "ads_enabled": False, "session_id": None}
    if usage.used_seconds >= FREE_LIMIT_SECONDS:
        db.commit()
        raise HTTPException(status_code=429, detail={"code": "FREE_LIMIT_REACHED", **usage_payload(db, user, usage)})
    session = db.query(VpnUsageSession).filter_by(user_id=user.id, active=True).first()
    now = datetime.now(timezone.utc)
    if session is None:
        session = VpnUsageSession(id=str(uuid4()), user_id=user.id, started_at=now, last_heartbeat_at=now, active=True)
        db.add(session)
    db.commit()
    return {"allowed": True, "unlimited": False, "ads_enabled": True, "session_id": session.id, **usage_payload(db, user, usage)}

@app.post("/usage/heartbeat")
def usage_heartbeat(session_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    usage = get_or_reset_usage_window(db, user.id)
    if premium_active(db, user.id):
        db.commit()
        return {"allowed": True, "unlimited": True, "ads_enabled": False}
    session = db.query(VpnUsageSession).filter_by(id=session_id, user_id=user.id, active=True).first()
    if session is None:
        raise HTTPException(status_code=409, detail="VPN usage session is not active")
    now = datetime.now(timezone.utc)
    elapsed = max(0, min(int((now - as_utc(session.last_heartbeat_at)).total_seconds()), HEARTBEAT_MAX_SECONDS))
    usage.used_seconds = min(FREE_LIMIT_SECONDS, usage.used_seconds + elapsed)
    session.last_heartbeat_at = now
    remaining = max(0, FREE_LIMIT_SECONDS - usage.used_seconds)
    if remaining == 0:
        session.active = False
    db.commit()
    return {"allowed": remaining > 0, "used_seconds": usage.used_seconds, "remaining_seconds": remaining, "ads_enabled": True}

@app.post("/usage/stop")
def usage_stop(session_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    usage = get_or_reset_usage_window(db, user.id)
    session = db.query(VpnUsageSession).filter_by(id=session_id, user_id=user.id, active=True).first()
    if session is not None and not premium_active(db, user.id):
        now = datetime.now(timezone.utc)
        elapsed = max(0, min(int((now - as_utc(session.last_heartbeat_at)).total_seconds()), HEARTBEAT_MAX_SECONDS))
        usage.used_seconds = min(FREE_LIMIT_SECONDS, usage.used_seconds + elapsed)
        session.active = False
    db.commit()
    return {"stopped": True, **usage_payload(db, user, usage)}

@app.get("/health")
def health():
    return {"status": "ok", "service": "DEXVPN API", "version": "0.3.0"}

@app.post("/auth/register", response_model=TokenOut)
def register(data: RegisterIn, db: Session = Depends(get_db)):
    email = data.email.lower()
    if db.query(User).filter_by(email=email).first():
        raise HTTPException(status_code=409, detail="Email already registered")
    user = User(email=email, password_hash=hash_password(data.password))
    db.add(user)
    db.commit()
    return TokenOut(access_token=create_token(email))

@app.post("/auth/login", response_model=TokenOut)
def login(data: LoginIn, db: Session = Depends(get_db)):
    user = db.query(User).filter_by(email=data.email.lower()).first()
    if not user or not verify_password(data.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Incorrect email or password")
    return TokenOut(access_token=create_token(user.email))

@app.get("/plans", response_model=list[PlanOut])
def plans(db: Session = Depends(get_db)):
    return db.query(Plan).filter_by(active=True).all()

@app.get("/me")
def me(user: User = Depends(current_user), db: Session = Depends(get_db)):
    sub = db.query(Subscription).filter_by(user_id=user.id).first()
    active = bool(sub and sub.status == "active" and not is_expired(sub.expires_at))
    usage = db.query(FreeUsageWindow).filter_by(user_id=user.id).first()
    used = usage.used_seconds if usage else 0
    remaining = max(0, FREE_LIMIT_SECONDS - used)
    return {
        "email": user.email,
        "subscription_status": "active" if active else "inactive",
        "is_premium": active,
        "ads_enabled": not active,
        "expires_at": sub.expires_at if sub else None,
        "free_limit_seconds": FREE_LIMIT_SECONDS,
        "free_used_seconds": used,
        "free_remaining_seconds": None if active else remaining,
        "free_window_resets_at": None if active or not usage or not usage.window_started_at else as_utc(usage.window_started_at) + FREE_WINDOW,
    }

@app.post("/billing/google-play/verify")
async def verify_google_play_purchase(data: PurchaseVerifyIn, user: User = Depends(current_user)):
    # TODO: verify purchase token through Google Play Developer API before activating.
    raise HTTPException(status_code=501, detail="Google Play server-side purchase verification is not configured.")

@app.post("/admin/provision")
async def admin_provision(
    data: AdminProvisionIn,
    x_admin_key: str = Header(default=""),
    db: Session = Depends(get_db),
):
    # Temporary operator provisioning endpoint. Protect this key and remove/replace
    # with a proper admin identity and Google Play purchase verification before launch.
    if not settings.admin_api_key or settings.admin_api_key == "CHANGE_ME" or x_admin_key != settings.admin_api_key:
        raise HTTPException(status_code=403, detail="Forbidden")
    user = db.query(User).filter_by(email=data.email.lower()).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found; register the user first")
    expires_at = datetime.now(timezone.utc) + timedelta(days=data.duration_days)
    panel = get_panel()
    try:
        provisioned = await panel.provision_client(str(user.id), expires_at)
    except ThreeXUIError as exc:
        raise HTTPException(status_code=502, detail=f"3x-ui provisioning failed: {exc}") from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"VPN provisioning failed: {type(exc).__name__}") from exc

    sub = db.query(Subscription).filter_by(user_id=user.id).first()
    if not sub:
        sub = Subscription(user_id=user.id)
        db.add(sub)
    sub.status = "active"
    sub.expires_at = expires_at
    sub.panel_client_id = provisioned.client_id
    db.commit()
    return {
        "status": "provisioned",
        "user": user.email,
        "expires_at": expires_at,
        "protocol": "vless",
        "links": provisioned.vless_uri.splitlines(),
    }

@app.get("/vpn/profile", response_model=ProfileOut)
async def get_vpn_profile(
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    sub = db.query(Subscription).filter_by(user_id=user.id).first()
    if not sub or sub.status != "active" or is_expired(sub.expires_at):
        raise HTTPException(status_code=403, detail="Active subscription required")
    if not sub.panel_client_id:
        raise HTTPException(status_code=409, detail="VPN client is not provisioned")
    try:
        panel = get_panel()
        links = await panel.get_client_links(sub.panel_client_id)
    except ThreeXUIError as exc:
        raise HTTPException(status_code=502, detail=f"Could not fetch VLESS profile: {exc}") from exc
    return ProfileOut(links=links, expires_at=sub.expires_at)

@app.post("/admin/revoke/{user_email}")
async def admin_revoke(
    user_email: str,
    x_admin_key: str = Header(default=""),
    db: Session = Depends(get_db),
):
    if not settings.admin_api_key or settings.admin_api_key == "CHANGE_ME" or x_admin_key != settings.admin_api_key:
        raise HTTPException(status_code=403, detail="Forbidden")
    user = db.query(User).filter_by(email=user_email.lower()).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    sub = db.query(Subscription).filter_by(user_id=user.id).first()
    if not sub:
        return {"status": "already_inactive"}
    if sub.panel_client_id:
        try:
            await get_panel().revoke_client(sub.panel_client_id)
        except ThreeXUIError as exc:
            raise HTTPException(status_code=502, detail=f"3x-ui revoke failed: {exc}") from exc
    sub.status = "inactive"
    db.commit()
    return {"status": "revoked", "user": user.email}
