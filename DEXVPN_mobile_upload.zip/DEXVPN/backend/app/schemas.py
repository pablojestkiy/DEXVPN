from pydantic import BaseModel, EmailStr, Field, ConfigDict
from datetime import datetime

class RegisterIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=10, max_length=128)

class LoginIn(BaseModel):
    email: EmailStr
    password: str

class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"

class PlanOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    code: str
    title: str
    duration_days: int
    price_minor: int
    currency: str

class ProfileOut(BaseModel):
    protocol: str = "vless"
    links: list[str]
    expires_at: datetime | None = None

class PurchaseVerifyIn(BaseModel):
    product_id: str
    purchase_token: str

class AdminProvisionIn(BaseModel):
    email: EmailStr
    duration_days: int = Field(default=30, ge=1, le=3650)
