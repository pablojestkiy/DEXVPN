# Подключение DEXVPN к 3x-ui

## 1. Подготовь панель
1. Открой 3x-ui по HTTPS.
2. В Settings → Security создай API Token. Токен даёт административный доступ к панели — храни его только на backend.
3. В Inbounds найди включённый inbound с протоколом VLESS.
4. Запиши его числовой ID. Не используй ID не-VLESS inbound.
5. Убедись, что inbound настроен и доступен извне, а share-link из панели корректно импортируется в совместимый VLESS-клиент.

## 2. Настрой backend/.env
Скопируй `.env.example` в `.env` и заполни:
- `PANEL_BASE_URL` — базовый HTTPS URL панели, без `/panel/api`.
- `PANEL_API_TOKEN` — Bearer API Token из 3x-ui.
- `PANEL_INBOUND_IDS` — ID VLESS inbound, например `2` или `2,4`.
- `JWT_SECRET` и `ADMIN_API_KEY` — длинные случайные секреты.
- `PANEL_FLOW` — оставь пустым, если не уверен; `xtls-rprx-vision` указывай только если выбранный inbound это поддерживает.

`PANEL_VERIFY_TLS=true` оставь включённым. Не отключай проверку сертификата на публичном сервере.

## 3. Запусти backend
```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

## 4. Выдача тестового доступа
Сначала зарегистрируй пользователя через `POST /auth/register`.
Затем вызови `POST /admin/provision` с заголовком `X-Admin-Key: <ADMIN_API_KEY>` и телом:
```json
{"email":"test@example.com","duration_days":30}
```
Backend создаст/обновит клиента в 3x-ui и вернёт VLESS-ссылки.
Пользователь получает свои ссылки через авторизованный `GET /vpn/profile`.

Для отзыва тестового доступа:
`POST /admin/revoke/{email}` с тем же заголовком.

## 5. API 3x-ui, используемые адаптером
- `GET /panel/api/clients/get/{email}`
- `POST /panel/api/clients/add`
- `POST /panel/api/clients/update/{email}`
- `GET /panel/api/clients/links/{email}`

Адаптер рассчитан на актуальный REST API MHSanaei/3x-ui с Bearer API Token. Старые форки/версии могут отличаться. Сверь endpoints со Swagger/API Docs именно своей панели.

## Безопасность
- Никогда не отправляй API token, пароль панели или VLESS-ссылки в чат и не встраивай их в APK.
- Не выставляй 3x-ui API напрямую в интернет без HTTPS и сетевых ограничений.
- Не открывай `/admin/provision` публичным пользователям. Перед запуском замени временный admin key на полноценную админ-аутентификацию.
- `/admin/provision` — операторская выдача тестового доступа, а не подтверждение платежа.
- Google Play purchase verification ещё не реализована: не продавай подписки до подключения Google Play Developer API и обработки продлений/возвратов.
