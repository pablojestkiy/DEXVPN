# Архитектура DEXVPN

```text
Android app
  ├── Login / plans / account
  ├── Android VpnService (TUN interface + consent)
  ├── XrayEngine bridge  <-- подключить Android Xray-core
  └── HTTPS API
        |
        v
DEXVPN Backend (FastAPI)
  ├── Auth + user identity
  ├── Plans + subscription state
  ├── VLESS profile delivery
  ├── Google Play purchase verification (TODO)
  └── PanelAdapter
        |
        v
Xray control panel API
        |
        v
Xray servers / inbounds / clients
```

Backend должен быть источником истины о подписке. Нельзя доверять `premium=true`, присланному Android-клиентом.
VLESS-профиль выдаётся только после серверной проверки действующей подписки.

## Panel adapter
`backend/app/panel/base.py` задаёт контракт адаптера. Его нужно реализовать под конкретную панель: у разных панелей отличаются API, авторизация, создание клиента, срок действия и отзыв доступа.

## Xray integration
`android/.../XrayEngine.kt` — точка интеграции. Нужен Android-совместимый Xray-core binding, который принимает конфигурацию и TUN fd (или поддерживаемый выбранной библиотекой способ подключения).
