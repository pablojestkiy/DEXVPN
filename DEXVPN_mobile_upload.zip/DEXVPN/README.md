# DEXVPN — Android + Backend starter

Проект-заготовка коммерческого Android VLESS-клиента и backend.

## Состав
- `android/` — Kotlin Android-приложение, VPN permission/service, экран подключения, API-клиент.
- `backend/` — FastAPI, регистрация/вход, тарифы, проверка статуса подписки, точки интеграции панели.
- `docs/` — архитектура и список обязательных работ перед публикацией.

## Важно: статус проекта
Это **исходный стартовый проект, а не готовый коммерческий VPN**.
Android-приложение содержит жизненный цикл `VpnService`, но реальный трафик не туннелируется, пока не будет подключён Android-совместимый Xray-core bridge в `XrayEngine.kt`.
Backend содержит интерфейс адаптера панели, но не создаёт клиентов, пока адаптер не будет реализован под точную панель (например, 3x-ui, Marzban, Hiddify или собственную).

Не добавляйте реальные пароли панели, приватные ключи или VLESS-ссылки в исходный код.

## Запуск backend
Требуется Python 3.11+:
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```
Документация API: `http://127.0.0.1:8000/docs`.

## Android
Откройте папку `android/` в Android Studio, установите JDK 17 и Android SDK 35, выполните Gradle Sync.
Перед релизом замените `BASE_URL` в `android/app/build.gradle.kts` на HTTPS-адрес своего backend.

## Что нужно для реального запуска
1. Название и версия панели + её API-документация.
2. Интеграция Android Xray-core с TUN file descriptor.
3. Реальная выдача/отзыв VLESS-профилей через панель.
4. Google Play Billing и серверная проверка purchase token через Google Play Developer API.
5. HTTPS, безопасная авторизация, политика конфиденциальности, VPN disclosure/consent, Data safety.
6. Тесты DNS/IPv6 leaks, переподключения, смены Wi-Fi/мобильной сети, срока подписки.
7. Подписанный AAB и прохождение проверки Google Play.

## Free + Premium (new in v0.3)

Backend now has a rolling 24-hour Free usage window, a 3-hour allowance, usage session start/heartbeat/stop endpoints, and an `ads_enabled` flag for the app. See `docs/FREE_PREMIUM_RU.md`. The Android app still needs to wire these calls to the real Xray tunnel lifecycle. AdMob SDK/ad units and Google Play Billing verification are not configured yet.

## 3x-ui integration (new in v0.2)

See `docs/3X_UI_SETUP_RU.md`. Configure `PANEL_BASE_URL`, `PANEL_API_TOKEN`,
and `PANEL_INBOUND_IDS` in `backend/.env`. The adapter uses the current 3x-ui
Bearer-token REST API to create/update a VLESS client and fetch its share links.

Operator test provisioning is available at `POST /admin/provision`; it is
deliberately separate from billing. Google Play purchase verification and the
Android Xray-core bridge are still TODOs, so this is not yet ready for paid
production use.
