package com.dexvpn.app.vpn

/**
 * Integration boundary for an Android-compatible Xray-core build.
 * Replace this stub with a maintained Android binding for your selected Xray version.
 * The binding must consume the TUN fd and validated Xray JSON config.
 * Never display "connected" until the core confirms the tunnel is active.
 */
object XrayEngine {
    fun start(tunFd: Int, xrayJsonConfig: String) {
        throw IllegalStateException(
            "Xray Android core bridge is not installed. Integrate the selected Xray-core binding."
        )
    }

    fun stop() {
        // Call native core stop method after integration.
    }
}
