package com.dexvpn.app.api

import com.dexvpn.app.BuildConfig
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class ApiClient {
    private val client = OkHttpClient.Builder()
        .callTimeout(20, TimeUnit.SECONDS)
        .build()

    fun healthCheck(): String {
        val request = Request.Builder().url(BuildConfig.BASE_URL + "health").get().build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("API error: ${response.code}")
            return response.body?.string().orEmpty()
        }
    }
}
