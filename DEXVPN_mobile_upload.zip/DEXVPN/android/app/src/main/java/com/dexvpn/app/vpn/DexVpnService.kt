package com.dexvpn.app.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.widget.Toast

class DexVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    private val channelId = "dexvpn_vpn"

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "DEXVPN", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> startTunnel()
            ACTION_DISCONNECT -> stopTunnel()
        }
        return START_NOT_STICKY
    }

    private fun startTunnel() {
        startForeground(1, notification("Подготовка VPN"))
        try {
            tun = Builder().setSession("DEXVPN")
                .addAddress("10.77.0.2", 32)
                .addDnsServer("1.1.1.1")
                .addRoute("0.0.0.0", 0)
                .establish() ?: error("Android не выдал TUN-интерфейс")

            // TUN interface alone does not tunnel traffic. Xray-core must consume tun.fd.
            XrayEngine.start(tun!!.fd, "")
        } catch (e: Exception) {
            tun?.close()
            tun = null
            stopForeground(STOP_FOREGROUND_REMOVE)
            Toast.makeText(this, "Xray-core пока не подключён: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun stopTunnel() {
        XrayEngine.stop()
        tun?.close()
        tun = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun notification(text: String): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, channelId) else Notification.Builder(this)
        return builder.setContentTitle("DEXVPN")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .build()
    }

    override fun onDestroy() {
        stopTunnel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_CONNECT = "com.dexvpn.app.CONNECT"
        const val ACTION_DISCONNECT = "com.dexvpn.app.DISCONNECT"
    }
}
