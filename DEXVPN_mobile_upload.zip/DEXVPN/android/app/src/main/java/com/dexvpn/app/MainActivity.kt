package com.dexvpn.app

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.dexvpn.app.vpn.DexVpnService

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 72, 48, 48)
        }
        layout.addView(TextView(this).apply { text = "DEXVPN"; textSize = 30f })
        status = TextView(this).apply {
            text = "Статус: не подключён"
            textSize = 16f
            setPadding(0, 32, 0, 32)
        }
        layout.addView(status)
        layout.addView(Button(this).apply {
            text = "Подключиться"
            setOnClickListener { requestVpnPermission() }
        })
        layout.addView(Button(this).apply {
            text = "Тарифы и подписка"
            setOnClickListener {
                Toast.makeText(this@MainActivity, "Подключите backend и Google Play Billing", Toast.LENGTH_LONG).show()
            }
        })
        setContentView(layout)
    }

    private fun requestVpnPermission() {
        val permissionIntent = VpnService.prepare(this)
        if (permissionIntent != null) startActivityForResult(permissionIntent, REQUEST_VPN)
        else startVpn()
    }

    @Deprecated("Use Activity Result API in production")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_VPN && resultCode == RESULT_OK) startVpn()
    }

    private fun startVpn() {
        startService(Intent(this, DexVpnService::class.java).setAction(DexVpnService.ACTION_CONNECT))
        status.text = "Статус: запуск VPN"
    }

    companion object { private const val REQUEST_VPN = 1001 }
}
