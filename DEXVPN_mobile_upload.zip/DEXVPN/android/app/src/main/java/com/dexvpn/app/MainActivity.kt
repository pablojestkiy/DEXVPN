package com.dexvpn.app

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.view.animation.DecelerateInterpolator
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 10, 16)
    private val panel = Color.rgb(27, 29, 40)
    private val panel2 = Color.rgb(35, 36, 49)
    private val purple = Color.rgb(151, 55, 255)
    private val muted = Color.rgb(174, 177, 194)
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var selectedTab = 0
    private var selectedServer = "🇩🇪  Германия"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        showScreen(0)
    }

    private fun showScreen(tab: Int) {
        selectedTab = tab
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.rgb(22, 13, 38), bg, Color.rgb(7, 8, 13)))
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(16))
        }
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(content) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bottomNav(), LinearLayout.LayoutParams(-1, dp(66)))
        setContentView(root)
        when (tab) { 0 -> home(); 1 -> servers(); else -> settings() }
    }

    private fun home() {
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val logo = text("DEXVPN", 29, Color.WHITE, true).apply {
            val styled = SpannableString("DEXVPN")
            styled.setSpan(ForegroundColorSpan(purple), 3, 6, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            text = styled
        }
        header.addView(logo, LinearLayout.LayoutParams(0, -2, 1f))
        val premium = button("♛  Premium", purple) { premiumDialog() }.apply {
            textSize = 14f
            setPadding(dp(16), dp(10), dp(16), dp(10))
        }
        header.addView(premium)
        content.addView(header)
        content.addView(space(24))
        content.addView(text("ЗАЩИТИ СВОЁ СОЕДИНЕНИЕ", 11, muted, true))
        content.addView(space(10))
        val circleBackground = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.rgb(20, 14, 34))
            setStroke(dp(3), purple)
        }
        val circle = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = circleBackground
            elevation = dp(8).toFloat()
            setOnClickListener {
                pulseConnectButton(this, circleBackground)
                Toast.makeText(this@MainActivity, "VPN-движок ещё подключается. Это пока демонстрационный интерфейс.", Toast.LENGTH_LONG).show()
            }
        }
        circle.addView(text("⏻", 58, Color.WHITE, true))
        circle.addView(text("Подключить", 19, Color.WHITE, true))
        val circleWrap = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(8)) }
        circleWrap.addView(circle, LinearLayout.LayoutParams(dp(236), dp(236)))
        content.addView(circleWrap)
        val status = text("●  Отключено", 15, muted, true).apply { gravity = Gravity.CENTER }
        content.addView(status)
        content.addView(space(20))
        content.addView(card {
            val row = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(text("🇩🇪", 30, Color.WHITE), LinearLayout.LayoutParams(dp(52), -2))
            val names = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
            names.addView(text("Германия", 17, Color.WHITE, true)); names.addView(text("Быстрый сервер", 13, muted))
            row.addView(names, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(text("›", 30, muted))
            addView(row)
            setOnClickListener { showScreen(1) }
        })
        content.addView(space(14))
        content.addView(card {
            addView(text("◷  Осталось времени", 15, muted))
            addView(space(4)); addView(text("1 ч 00 м", 27, Color.WHITE, true))
            addView(space(10))
            val bar = View(this@MainActivity).apply { background = shape(purple, purple, 0, 20) }
            addView(bar, LinearLayout.LayoutParams(-1, dp(8)))
            addView(text("Бесплатный доступ: 1 час за просмотр рекламы", 11, muted))
        })
        content.addView(space(14))
        content.addView(button("▶   Получить ещё 1 час     ›", purple) {
            Toast.makeText(this, "Просмотр рекламы AdMob будет подключён отдельно", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(-1, dp(58)))
        content.addView(space(12))
        content.addView(card {
            addView(text("РЕКЛАМА", 10, muted, true)); addView(space(5))
            addView(text("Здесь будет вознаграждаемое видео AdMob", 14, Color.WHITE))
            addView(text("Посмотри ролик и получи ещё 1 час VPN", 12, muted))
        })
    }


    // Короткая неоновая пульсация при нажатии. Не меняет фиктивный статус VPN.
    private fun pulseConnectButton(view: View, ring: GradientDrawable) {
        view.animate().cancel()
        val scale = ValueAnimator.ofFloat(1f, 1.055f, 1f).apply {
            duration = 900L
            repeatCount = 2
            interpolator = DecelerateInterpolator()
            addUpdateListener { animator ->
                val value = animator.animatedValue as Float
                view.scaleX = value
                view.scaleY = value
                view.elevation = dp((8f + (value - 1f) * 150f).toInt()).toFloat()
            }
        }
        val glow = ValueAnimator.ofObject(
            ArgbEvaluator(), purple, Color.rgb(218, 164, 255), purple
        ).apply {
            duration = 900L
            repeatCount = 2
            addUpdateListener { animator ->
                ring.setStroke(dp(3), animator.animatedValue as Int)
            }
        }
        scale.start()
        glow.start()
        scale.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                view.scaleX = 1f
                view.scaleY = 1f
                view.elevation = dp(8).toFloat()
                ring.setStroke(dp(3), purple)
            }
        })
    }

    private fun servers() {
        content.addView(text("Серверы", 27, Color.WHITE, true)); content.addView(space(18))
        content.addView(text("Выбери расположение", 14, muted)); content.addView(space(12))
        val list = listOf("🇩🇪" to "Германия", "🇳🇱" to "Нидерланды", "🇫🇷" to "Франция", "🇬🇧" to "Великобритания", "🇵🇱" to "Польша", "🇹🇷" to "Турция", "🇸🇬" to "Сингапур", "🇺🇸" to "США")
        list.forEachIndexed { i, item ->
            content.addView(card {
                val row = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
                row.addView(text(item.first, 29, Color.WHITE), LinearLayout.LayoutParams(dp(55), -2))
                val col = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
                col.addView(text(item.second, 16, Color.WHITE, true)); col.addView(text(if (i == 0) "Быстрый" else "Доступен", 12, muted))
                row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(text(if (i == 0) "45 мс" else "— мс", 14, if (i == 0) Color.GREEN else muted))
                row.addView(text(if (selectedServer.contains(item.second)) "  ◉" else "  ○", 20, purple))
                addView(row)
                setOnClickListener { selectedServer = "${item.first}  ${item.second}"; showScreen(1) }
            })
            content.addView(space(9))
        }
    }

    private fun settings() {
        content.addView(text("Настройки", 27, Color.WHITE, true)); content.addView(space(18))
        listOf("Аккаунт", "Язык приложения       Русский", "Уведомления", "Политика конфиденциальности", "Условия использования", "О приложении       DEXVPN 0.1.0").forEach {
            content.addView(card { addView(text(it, 15, Color.WHITE, true)) }); content.addView(space(9))
        }
        content.addView(button("Premium — убрать рекламу", purple) { premiumDialog() })
    }

    private fun bottomNav(): View {
        val nav = LinearLayout(this).apply { gravity = Gravity.CENTER; setBackgroundColor(Color.rgb(18, 19, 28)); setPadding(dp(8), dp(5), dp(8), dp(5)) }
        listOf("⌂\nГлавная", "▱\nСерверы", "⚙\nНастройки").forEachIndexed { i, label ->
            val t = text(label, 13, if (selectedTab == i) purple else muted, selectedTab == i).apply { gravity = Gravity.CENTER; setOnClickListener { showScreen(i) } }
            nav.addView(t, LinearLayout.LayoutParams(0, -1, 1f))
        }
        return nav
    }

    private fun premiumDialog() {
        android.app.AlertDialog.Builder(this).setTitle("DEXVPN Premium")
            .setMessage("Безлимитное подключение и полное отсутствие рекламы.\n\nПокупка подписки пока находится в разработке.")
            .setPositiveButton("Понятно", null).show()
    }

    private fun card(build: LinearLayout.() -> Unit): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14)); background = shape(panel, Color.rgb(48, 49, 64), 1, 18); build()
    }
    private fun button(label: String, color: Int, action: () -> Unit): TextView = TextView(this).apply {
        text = label; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        background = shape(color, color, 0, 16); setPadding(dp(14), dp(12), dp(14), dp(12)); setOnClickListener { action() }
    }
    private fun text(value: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size.toFloat(); setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun shape(color: Int, stroke: Int, width: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); if (width > 0) setStroke(dp(width), stroke)
    }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
