package com.dexvpn.app.model

data class Server(
    val id: String,
    val name: String,
    val countryCode: String,
    val latencyMs: Int? = null,
    val available: Boolean = true
)
